# TÜRKAİ

Türkçe sesli yapay zekâ asistanı (PWA).

## Yayınlama
1. Bu klasörün içindekileri (zip'in kendisini değil) Netlify'a yükle.
2. Telefonda siteyi Safari'de aç, Paylaş → "Ana Ekrana Ekle".
3. Gemini API anahtarını ilk kurulumda gir.

## Dosyalar
`index.html` uygulamanın kendisi, `sw.js` çevrimdışı önbellek, `manifest.webmanifest` ve `icon-*.png` ana ekran simgeleri.

## Kurulum sesi (bir kez)
1. `ses-uret.html` sayfasını aç (bilgisayarda çift tıkla), Gemini anahtarını yapıştır, "Üret ve indir"e bas.
2. İnen `ob-w.wav`, `ob-k.wav`, `ob-p.wav` dosyalarını `ses` klasörüne koy, projeyi yeniden yükle, `ses-uret.html`'i sil.
Dosyalar yoksa kurulum, anahtar girildikten sonra sesi Gemini'den canlı alır.
Ses: `index.html` içindeki `VOICE` (varsayılan Charon, erkek). Canlı konuşma da aynı sesi kullanır.
